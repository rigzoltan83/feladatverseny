--
-- PostgreSQL database dump
--

\restrict DdNfSCel8eg3ChjN41CF5CHde4jy3cmNFhKhzvgGb0lUDb6rKypD8tZ8jm3WC9L

-- Dumped from database version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)
-- Dumped by pg_dump version 16.15 (Ubuntu 16.15-0ubuntu0.24.04.1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Data for Name: source_year; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.source_year (id, year_number, is_active) FROM stdin;
1	1990	t
2	1991	t
3	1992	t
4	1993	t
5	1994	t
6	1995	t
7	1996	t
8	1997	t
9	1998	t
10	1999	t
11	2000	t
12	2001	t
13	2002	t
14	2003	t
15	2004	t
16	2005	t
17	2006	t
18	2007	t
19	2008	t
20	2009	t
21	2010	t
22	2011	t
23	2012	t
24	2013	t
25	2014	t
26	2015	t
27	2016	t
28	2017	t
29	2018	t
30	2019	t
31	2020	t
32	2021	t
33	2022	t
34	2023	t
35	2024	t
36	2025	t
37	2026	t
\.


--
-- Data for Name: question; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.question (id, source_year_id, original_position, difficulty, question_text, image_path, explanation, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: answer_option; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.answer_option (id, question_id, original_position, answer_text, image_path, is_correct) FROM stdin;
\.


--
-- Data for Name: grade; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.grade (id, grade_number, name) FROM stdin;
1	1	1. évfolyam
2	2	2. évfolyam
3	3	3. évfolyam
4	4	4. évfolyam
5	5	5. évfolyam
6	6	6. évfolyam
7	7	7. évfolyam
8	8	8. évfolyam
9	9	9. évfolyam
10	10	10. évfolyam
11	11	11. évfolyam
12	12	12. évfolyam
\.


--
-- Data for Name: question_grade; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.question_grade (question_id, grade_id) FROM stdin;
\.


--
-- Data for Name: topic; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.topic (id, name, is_active) FROM stdin;
1	Matematika	t
2	Természetismeret	t
3	Magyar nyelv	t
4	Történelem	t
5	Logika	t
6	Általános műveltség	t
7	Informatika	t
8	Sport	t
\.


--
-- Data for Name: question_topic; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.question_topic (question_id, topic_id) FROM stdin;
\.


--
-- Data for Name: test_template; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_template (id, name, description, question_count, shuffle_questions, shuffle_answers, is_active, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: test_template_grade; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_template_grade (test_template_id, grade_id) FROM stdin;
\.


--
-- Data for Name: test_template_topic; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.test_template_topic (test_template_id, topic_id) FROM stdin;
\.


--
-- Name: answer_option_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.answer_option_id_seq', 1, false);


--
-- Name: grade_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.grade_id_seq', 12, true);


--
-- Name: question_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.question_id_seq', 1, false);


--
-- Name: source_year_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.source_year_id_seq', 37, true);


--
-- Name: test_template_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.test_template_id_seq', 1, false);


--
-- Name: topic_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.topic_id_seq', 8, true);


--
-- PostgreSQL database dump complete
--

\unrestrict DdNfSCel8eg3ChjN41CF5CHde4jy3cmNFhKhzvgGb0lUDb6rKypD8tZ8jm3WC9L

